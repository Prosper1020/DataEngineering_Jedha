package jedha.cli

import java.time.LocalDateTime.parse
import java.time.format.DateTimeFormatter.ofPattern

import jedha.calendar.{CalendarEntry, CalendarService}

import scala.concurrent.duration.{Duration, MINUTES}

class AddEntry(entry: Option[CalendarEntry]) extends CommandExecution {
  def this() {
    this(Option.empty)
  }

  override def run(): Unit = {
    println("Enter the name of the entry " + entry.map(e => f"(Press enter to keep ${e.name})").getOrElse(""))
    val entryNameInput: String = askString()
    val entryName = if (entryNameInput.length == 0) entry.get.name else entryNameInput

    println("Enter the starting date of the entry YYYY-MM-DD HH:mm " + entry.map(e => s"(Press enter to keep ${e.start})").getOrElse(""))
    val entryStartInput: String = askString()
    val entryStart = if (entryStartInput.length == 0) entry.get.start else parse(entryStartInput, ofPattern("yyyy-MM-dd HH:mm"))

    println("Enter the duration of the entry in minutes " + entry.map(e => s"(Press enter to keep ${e.duration})").getOrElse(""))
    val entryDurationInput: String = askString()
    val entryDuration = if (entryDurationInput.length == 0) entry.get.duration else Duration(entryDurationInput.toInt, MINUTES)
    CalendarService.addEntry(CalendarEntry(entryName, entryStart, entryDuration))

    new Menu().run()
  }
}