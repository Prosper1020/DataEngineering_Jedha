package jedha.cli

import jedha.calendar.CalendarService

class ModifyEntry extends CommandExecution {
  override def run(): Unit = {
    val entryToModify = selectEntry("What calendar entry do you want to modify?")
    CalendarService.removeEntry(entryToModify)
    new AddEntry(Option(entryToModify)).run()
  }
}