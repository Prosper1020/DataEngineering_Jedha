package jedha.cli

import jedha.calendar.CalendarService

class RemoveEntry extends CommandExecution {
  override def run(): Unit = {
    CalendarService.removeEntry(selectEntry("What calendar entry do you want to delete?"))
    new Menu().run()
  }
}