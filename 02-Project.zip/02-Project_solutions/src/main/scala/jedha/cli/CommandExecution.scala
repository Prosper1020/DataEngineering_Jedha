package jedha.cli

import jedha.calendar.{CalendarEntry, CalendarService}

import scala.io.StdIn.{readInt, readLine}

// This is the trait that will define all the other CommandExecution present in this package.
// Note that some function are already implemented to avoid code duplication
trait CommandExecution {
  def askString(): String = {
    print("> ")
    readLine()
  }

  def askInt(): Int = {
    print("> ")
    readInt()
  }

  def selectEntry(question: String): CalendarEntry = {
    println(CalendarService.calendar)
    println(question)
    CalendarService.calendar.entries(askInt())
  }

  def run(): Unit
}