package jedha.cli

class Menu extends CommandExecution {
  def run(): Unit = {
    println("1. View Calendar")
    println("2. Add entry")
    println("3. Modify entry")
    println("4. Delete entry")
    println("5. Exit")

    val userChoice = askInt()
    if (userChoice == 1) {
      new ViewCalendar().run()
    } else if (userChoice == 2) {
      new AddEntry().run()
    } else if (userChoice == 3) {
      new ModifyEntry().run()
    } else if (userChoice == 4) {
      new RemoveEntry().run()
    } else if (userChoice == 5) {
      new Exit().run()
    } else {
      println("Sorry I did not understand what you want...")
      new Menu().run()
    }
  }
}