package jedha.cli

import jedha.calendar.CalendarService

class ViewCalendar extends CommandExecution {
  override def run(): Unit = {
    println(CalendarService.calendar)
    new Menu().run()
  }
}