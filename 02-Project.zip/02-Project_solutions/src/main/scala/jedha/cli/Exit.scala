package jedha.cli

class Exit extends CommandExecution {
  override def run(): Unit = {
    println("Bye Bye.")
  }
}