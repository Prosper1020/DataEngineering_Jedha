package jedha

import jedha.cli.Menu

object CalendarCLI {
  // In this version, No for loop.
  // The user will create a chain of action that starts with the menu.
  // You will see by looking at the code that Menu will trigger different implementation of CommandExecution
  // It is alright if the students keep the for loop and focus on create classes for the calendar.
  def main(args: Array[String]): Unit = {
    new Menu().run()
  }
}