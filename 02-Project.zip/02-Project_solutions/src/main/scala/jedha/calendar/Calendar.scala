package jedha.calendar

class Calendar(var entries: List[CalendarEntry]) {
  def this() {
    this(List());
  }

  def addEntry(entry: CalendarEntry): Unit = {
    entries = entry :: this.entries
  }

  def removeEntry(entryToDelete: CalendarEntry): Unit = {
    entries = entries.filter(entry => entry != entryToDelete)
  }

  // I decided to print the calendar using toString methods. It is also a correct implementation to create a singleton
  // class that would handle the printing.
  override def toString: String = {
    val lineBreak = sys.props("line.separator")
    if(entries.isEmpty){
      f"$lineBreak Your Calendar is empty.$lineBreak "
    }else{
      val entriesStr = entries.zipWithIndex.map( el => f"${el._2}. ${el._1}").mkString(sys.props("line.separator"))
      f"Calendar: $lineBreak$entriesStr$lineBreak"
    }
  }
}
