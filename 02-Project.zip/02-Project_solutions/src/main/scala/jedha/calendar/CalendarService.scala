package jedha.calendar

object CalendarService {
  var calendar: Calendar = new Calendar()

  def addEntry(entry: CalendarEntry):Unit = {
    calendar.addEntry(entry)
  }

  def removeEntry(entry: CalendarEntry):Unit = {
    calendar.removeEntry(entry)
  }

}
