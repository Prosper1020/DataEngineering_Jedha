package jedha.calendar

import java.time.LocalDateTime

import scala.concurrent.duration.Duration

case class CalendarEntry(name: String, start: LocalDateTime, duration: Duration) {
  override def toString: String = {
    f"$name - $start - $duration"
  }
}
